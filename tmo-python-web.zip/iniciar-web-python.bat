@echo off
title TMO Monitor & Mailer - Python Edition
cd /d "%~dp0"
echo ========================================================
echo   Iniciando Plataforma Web de Medicion de TMO (Python)
echo ========================================================
echo Abriendo navegador en http://localhost:5000 ...
start "" "http://localhost:5000"
py server.py
if errorlevel 1 (
    "C:\Users\Jornada 1\AppData\Local\Python\bin\python.exe" server.py
)
pause
