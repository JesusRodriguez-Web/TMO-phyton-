/**
 * Lógica Frontend - TMO Analytics & Mailer
 */

// Estado global de la aplicación
let appData = {
  resumen: null,
  trabajadores: [],
  rechazados: [],
  config: null
};

let historialCorreos = [];
let filtroActual = 'todos';
let busquedaTexto = '';
let chartBarras = null;
let chartDona = null;

// Elementos de la UI
const toastEl = document.getElementById('appToast');
const toastInstance = new bootstrap.Toast(toastEl, { delay: 4000 });

function mostrarToast(mensaje, tipo = 'primary') {
  const toastMensaje = document.getElementById('toastMensaje');
  const toastIcon = document.getElementById('toastIcon');
  toastMensaje.textContent = mensaje;
  
  toastEl.className = `toast align-items-center text-bg-${tipo} border-0 shadow-lg rounded-3`;
  if (tipo === 'success') {
    toastIcon.className = 'bi bi-check-circle-fill fs-5';
  } else if (tipo === 'danger') {
    toastIcon.className = 'bi bi-exclamation-triangle-fill fs-5';
  } else {
    toastIcon.className = 'bi bi-info-circle-fill fs-5';
  }
  
  toastInstance.show();
}

// Inicialización al cargar el DOM
document.addEventListener('DOMContentLoaded', () => {
  inicializarEventos();
  actualizarDatos();
  cargarHistorialCorreos();
});

function inicializarEventos() {
  // Botón cargar muestra
  document.getElementById('btnCargarSample').addEventListener('click', cargarDatosMuestra);

  // Botón refrescar
  const btnActualizar = document.querySelector('button[onclick="actualizarDatos()"]');
  if (btnActualizar) btnActualizar.onclick = actualizarDatos;

  // Slider de TMO Límite
  const rangeTmo = document.getElementById('rangeTmoLimite');
  const lblSlider = document.getElementById('lblValorSlider');
  rangeTmo.addEventListener('input', (e) => {
    lblSlider.textContent = e.target.value + 's';
  });

  document.getElementById('btnAplicarLimite').addEventListener('click', () => {
    const nuevoLimite = Number(rangeTmo.value);
    guardarLimiteTmo(nuevoLimite);
  });

  // Buscador de trabajadores
  document.getElementById('inputBuscarAgente').addEventListener('input', (e) => {
    busquedaTexto = e.target.value.toLowerCase().trim();
    renderizarTablaTrabajadores();
  });

  // Filtros de estado (píldoras)
  document.querySelectorAll('.badge-filter').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.badge-filter').forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      filtroActual = e.currentTarget.dataset.filtro;
      renderizarTablaTrabajadores();
    });
  });

  // Subida de archivo (Dropzone y File Input)
  const dropzone = document.getElementById('dropzoneArchivo');
  const inputArchivo = document.getElementById('inputArchivo');

  dropzone.addEventListener('click', () => inputArchivo.click());
  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });
  dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
      subirArchivo(e.dataTransfer.files[0]);
    }
  });
  inputArchivo.addEventListener('change', (e) => {
    if (e.target.files.length) {
      subirArchivo(e.target.files[0]);
    }
  });

  // Formulario de Nueva Gestión Manual
  document.getElementById('formNuevaGestion').addEventListener('submit', (e) => {
    e.preventDefault();
    guardarGestionManual();
  });

  // Modal Enviar Correo - Eventos
  document.getElementById('btnRefrescarPreview').addEventListener('click', actualizarPreviewCorreo);
  document.getElementById('modalCorreoPlantilla').addEventListener('change', actualizarPreviewCorreo);
  document.getElementById('modalCorreoNota').addEventListener('input', actualizarPreviewCorreo);
  document.getElementById('btnConfirmarEnvioCorreo').addEventListener('click', ejecutarEnvioIndividual);

  // Envío Masivo
  document.getElementById('btnEjecutarEnvioMasivo').addEventListener('click', ejecutarEnvioMasivo);

  // Reporte a Supervisor
  document.getElementById('btnEnviarReporteSupervisor').addEventListener('click', enviarReporteSupervisor);

  // Vaciar Buzón
  document.getElementById('btnVaciarHistorial').addEventListener('click', vaciarHistorial);

  // Configuración & SMTP
  document.getElementById('btnGuardarConfiguracion').addEventListener('click', guardarConfiguracionCompleta);
  document.getElementById('btnTestSmtp').addEventListener('click', probarSmtp);

  // Alternar campos SMTP según modo
  document.querySelectorAll('input[name="cfgModoEnvio"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const seccion = document.getElementById('seccionSmtpCampos');
      if (e.target.value === 'smtp') {
        seccion.classList.remove('d-none');
      } else {
        seccion.classList.add('d-none');
      }
    });
  });

  // Al cambiar pestañas, reajustar charts
  document.getElementById('tab-graficos-btn').addEventListener('shown.bs.tab', () => {
    if (chartBarras) chartBarras.resize();
    if (chartDona) chartDona.resize();
  });
}

// ---------------------------------------------------------------------------
// OBTENCIÓN Y RENDERIZADO DE DATOS
// ---------------------------------------------------------------------------

async function actualizarDatos() {
  try {
    const res = await fetch('/api/data');
    if (!res.ok) throw new Error('Error al conectar con la API');
    const data = await res.json();
    
    appData = data;
    
    renderizarKpis(data.resumen);
    renderizarTablaTrabajadores();
    renderizarTablaRechazados(data.rechazados);
    actualizarGraficos();
    cargarConfiguracionEnModal(data.config);

  } catch (err) {
    console.error('Error cargando datos:', err);
    mostrarToast('No se pudieron cargar los datos: ' + err.message, 'danger');
  }
}

function renderizarKpis(resumen) {
  if (!resumen) return;

  // Banner
  document.getElementById('lblNombreArchivo').textContent = resumen.metadatosArchivo ? resumen.metadatosArchivo.nombre : 'Archivo de Operaciones';
  document.getElementById('lblDetalleArchivo').textContent = `Procesado: ${resumen.metadatosArchivo?.fechaCarga || 'Hoy'} | ${resumen.registrosRecibidos} registros recibidos`;
  document.getElementById('badgeMetaTmo').textContent = `${resumen.tmoLimite} s`;
  document.getElementById('badgeModoEnvio').textContent = appData.config?.modoEnvio === 'smtp' ? 'Modo SMTP Real' : 'Buzón Web Activo';

  // Slider
  document.getElementById('rangeTmoLimite').value = resumen.tmoLimite;
  document.getElementById('lblValorSlider').textContent = resumen.tmoLimite + 's';

  // KPI 1
  document.getElementById('kpiTmoGlobal').textContent = `${resumen.tmoPromedioGlobal} s`;
  document.getElementById('kpiTmoSubtext').textContent = `Meta: ${resumen.tmoLimite} seg (${resumen.tmoPromedioGlobal <= resumen.tmoLimite ? '✅ Cumple' : '⚠️ Supera'})`;

  // KPI 2
  document.getElementById('kpiTotalTrabajadores').textContent = resumen.totalTrabajadores;
  document.getElementById('kpiEvaluablesSubtext').textContent = `${resumen.evaluables} evaluables con datos`;

  // KPI 3
  document.getElementById('kpiAprobados').textContent = resumen.aprobados;
  document.getElementById('kpiPctAprobados').textContent = `${resumen.porcentajeAprobados}% dentro de meta`;

  // KPI 4
  document.getElementById('kpiRevision').textContent = resumen.requierenRevision;
  document.getElementById('kpiPctRevision').textContent = `${resumen.porcentajeRevision}% requieren revisión`;

  // KPI 5
  document.getElementById('kpiGestionesValidas').textContent = resumen.registrosValidos;
  document.getElementById('kpiRechazadosSubtext').textContent = `${resumen.registrosRechazados} inconsistencias filtradas`;

  // Contadores de pestañas y filtros
  document.getElementById('tabCountTrabajadores').textContent = resumen.totalTrabajadores;
  document.getElementById('tabCountRechazados').textContent = resumen.registrosRechazados;
  document.getElementById('filtroCountTodos').textContent = resumen.totalTrabajadores;
  document.getElementById('filtroCountAprobados').textContent = resumen.aprobados;
  document.getElementById('filtroCountRevision').textContent = resumen.requierenRevision;
  document.getElementById('filtroCountSinDatos').textContent = resumen.sinDatos;

  // Contadores para modal masivo
  document.getElementById('masivoCountTodos').textContent = resumen.totalTrabajadores;
  document.getElementById('masivoCountRevision').textContent = resumen.requierenRevision;
  document.getElementById('masivoCountAprobados').textContent = resumen.aprobados;
}

function renderizarTablaTrabajadores() {
  const tbody = document.getElementById('tablaTrabajadoresCuerpo');
  tbody.innerHTML = '';

  let lista = appData.trabajadores || [];

  // Filtrar por criterio
  if (filtroActual === 'aprobados') {
    lista = lista.filter(t => t.clasificacion === 'APROBADO');
  } else if (filtroActual === 'revision') {
    lista = lista.filter(t => t.clasificacion === 'REQUIERE REVISIÓN');
  } else if (filtroActual === 'sindatos') {
    lista = lista.filter(t => t.clasificacion !== 'APROBADO' && t.clasificacion !== 'REQUIERE REVISIÓN');
  }

  // Filtrar por texto de búsqueda
  if (busquedaTexto) {
    lista = lista.filter(t => t.agente.toLowerCase().includes(busquedaTexto) || (t.email && t.email.toLowerCase().includes(busquedaTexto)));
  }

  if (!lista.length) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center py-5 text-muted">No se encontraron trabajadores con los filtros aplicados.</td></tr>`;
    return;
  }

  lista.forEach(t => {
    const tr = document.createElement('tr');

    // Iniciales para avatar
    const iniciales = t.agente.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase();

    // Estado Badge
    let badgeHtml = '';
    let tmoPillClass = 'neutral';
    if (t.clasificacion === 'APROBADO') {
      badgeHtml = `<span class="badge-aprobado"><i class="bi bi-check-circle-fill"></i> APROBADO</span>`;
      tmoPillClass = 'good';
    } else if (t.clasificacion === 'REQUIERE REVISIÓN') {
      badgeHtml = `<span class="badge-revision"><i class="bi bi-exclamation-triangle-fill"></i> REQUIERE REVISIÓN</span>`;
      tmoPillClass = 'bad';
    } else {
      badgeHtml = `<span class="badge-sindatos"><i class="bi bi-question-circle"></i> SIN DATOS</span>`;
      tmoPillClass = 'neutral';
    }

    // Diferencia
    let difHtml = '<span class="text-muted">-</span>';
    if (t.diferencia !== null) {
      if (t.diferencia > 0) {
        difHtml = `<span class="text-danger fw-bold">+${t.diferencia}s</span>`;
      } else if (t.diferencia < 0) {
        difHtml = `<span class="text-success fw-bold">${t.diferencia}s</span>`;
      } else {
        difHtml = `<span class="text-success fw-bold">0s (En meta)</span>`;
      }
    }

    tr.innerHTML = `
      <td>
        <div class="d-flex align-items-center gap-2">
          <div class="avatar-worker">${iniciales}</div>
          <div>
            <div class="fw-bold text-dark">${t.agente}</div>
            <div class="text-muted small">${t.rechazados > 0 ? `<span class="text-danger"><i class="bi bi-exclamation-circle"></i> ${t.rechazados} rechazados</span>` : 'Sin rechazos'}</div>
          </div>
        </div>
      </td>
      <td>
        <div class="d-flex align-items-center gap-1">
          <input type="email" class="form-control form-control-sm border-0 bg-transparent text-secondary py-0 px-1 input-email-worker" 
                 value="${t.email || ''}" 
                 data-agente="${t.agente}"
                 title="Haz clic para editar el correo"
                 style="max-width: 200px; font-size: 0.82rem;">
          <button class="btn btn-link btn-sm p-0 text-muted btn-guardar-email d-none" title="Guardar correo">
            <i class="bi bi-check-lg text-success"></i>
          </button>
        </div>
      </td>
      <td class="text-center fw-semibold">${t.gestionesValidas}</td>
      <td class="text-center text-muted">${t.tiempoAcumulado !== null ? t.tiempoAcumulado + 's' : '-'}</td>
      <td class="text-center">
        <span class="tmo-pill ${tmoPillClass}">
          ${t.tmoPromedio !== null ? t.tmoPromedio + 's' : 'N/A'}
        </span>
      </td>
      <td class="text-center text-muted fw-semibold">${t.tmoLimite}s</td>
      <td class="text-center">${difHtml}</td>
      <td class="text-center">${badgeHtml}</td>
      <td class="text-end">
        <div class="d-inline-flex gap-1">
          <button class="btn btn-outline-primary btn-sm rounded-3 btn-abrir-correo" data-agente="${t.agente}" title="Enviar correo a este trabajador">
            <i class="bi bi-envelope-fill me-1"></i> Correo
          </button>
          <button class="btn btn-light btn-sm rounded-3 btn-ver-gestiones" data-agente="${t.agente}" title="Ver llamadas/gestiones">
            <i class="bi bi-list-ul"></i>
          </button>
        </div>
      </td>
    `;

    tbody.appendChild(tr);
  });

  // Asignar listeners de acciones en tabla
  document.querySelectorAll('.btn-abrir-correo').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const agente = e.currentTarget.dataset.agente;
      abrirModalCorreo(agente);
    });
  });

  document.querySelectorAll('.btn-ver-gestiones').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const agente = e.currentTarget.dataset.agente;
      verGestionesTrabajador(agente);
    });
  });

  // Edición rápida de correo en tabla
  document.querySelectorAll('.input-email-worker').forEach(input => {
    input.addEventListener('focus', (e) => {
      e.target.classList.remove('border-0', 'bg-transparent');
      e.target.classList.add('border', 'bg-white');
    });
    input.addEventListener('blur', async (e) => {
      e.target.classList.add('border-0', 'bg-transparent');
      e.target.classList.remove('border', 'bg-white');
      const agente = e.target.dataset.agente;
      const nuevoEmail = e.target.value.trim();
      if (nuevoEmail && nuevoEmail.includes('@')) {
        await guardarCorreoTrabajador(agente, nuevoEmail);
      }
    });
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') e.target.blur();
    });
  });
}

async function guardarCorreoTrabajador(agente, email) {
  try {
    const res = await fetch('/api/worker-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agente, email })
    });
    if (res.ok) {
      const t = appData.trabajadores.find(w => w.agente === agente);
      if (t) t.email = email;
      mostrarToast(`Correo actualizado para ${agente}`, 'success');
    }
  } catch (e) {
    console.error('Error guardando correo:', e);
  }
}

function renderizarTablaRechazados(rechazados) {
  const tbody = document.getElementById('tablaRechazadosCuerpo');
  tbody.innerHTML = '';

  if (!rechazados || !rechazados.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-muted">No se detectaron registros rechazados.</td></tr>`;
    return;
  }

  rechazados.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="fw-bold">${r['Fila origen'] || '-'}</td>
      <td><code>${r['ID Gestion'] || '-'}</code></td>
      <td class="fw-semibold">${r.Agente || '<span class="text-danger italic">No identificado</span>'}</td>
      <td class="text-danger fw-bold">${r['Tiempo de gestión'] ?? '-'}</td>
      <td class="small text-muted">${r.Fecha || '-'}</td>
      <td><span class="badge bg-light text-dark border">${r.Canal || 'Voz'}</span></td>
      <td>${r['Campaña'] || '-'}</td>
      <td><span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1">${r['Motivo rechazo']}</span></td>
    `;
    tbody.appendChild(tr);
  });
}

// ---------------------------------------------------------------------------
// GRÁFICOS INTERACTIVOS (CHART.JS)
// ---------------------------------------------------------------------------

function actualizarGraficos() {
  const trabajadores = (appData.trabajadores || []).filter(t => t.gestionesValidas > 0 && t.tmoPromedio !== null);
  const limite = Number(appData.config?.tmoLimite || 20);

  // Gráfico 1: Barras Comparativas
  const ctxBarras = document.getElementById('chartTmoBarras').getContext('2d');
  const labels = trabajadores.map(t => t.agente);
  const dataTmo = trabajadores.map(t => t.tmoPromedio);
  const backgroundColors = trabajadores.map(t => t.tmoPromedio <= limite ? '#10b981' : '#ef4444');

  if (chartBarras) chartBarras.destroy();

  chartBarras = new Chart(ctxBarras, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'TMO Promedio (seg)',
          data: dataTmo,
          backgroundColor: backgroundColors,
          borderRadius: 6,
          borderSkipped: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => `TMO: ${ctx.parsed.y}s (Meta: ${limite}s, Dif: ${ctx.parsed.y - limite > 0 ? '+' : ''}${(ctx.parsed.y - limite).toFixed(1)}s)`
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: '#f1f5f9' },
          ticks: { callback: (v) => v + 's' }
        },
        x: {
          grid: { display: false },
          ticks: { font: { size: 11 }, maxRotation: 45, minRotation: 45 }
        }
      }
    }
  });

  // Gráfico 2: Dona de Cumplimiento
  const ctxDona = document.getElementById('chartCumplimientoDona').getContext('2d');
  const r = appData.resumen || { aprobados: 0, requierenRevision: 0, sinDatos: 0 };
  
  document.getElementById('lblChartAprobados').textContent = `${r.aprobados} (${r.porcentajeAprobados}%)`;
  document.getElementById('lblChartRevision').textContent = `${r.requierenRevision} (${r.porcentajeRevision}%)`;
  document.getElementById('lblChartSinDatos').textContent = `${r.sinDatos}`;

  if (chartDona) chartDona.destroy();

  chartDona = new Chart(ctxDona, {
    type: 'doughnut',
    data: {
      labels: ['Aprobados', 'Requieren Revisión', 'Sin Datos'],
      datasets: [
        {
          data: [r.aprobados, r.requierenRevision, r.sinDatos],
          backgroundColor: ['#10b981', '#ef4444', '#cbd5e1'],
          borderWidth: 0,
          hoverOffset: 4
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '70%',
      plugins: {
        legend: { display: false }
      }
    }
  });
}

// ---------------------------------------------------------------------------
// GESTIÓN Y ENVÍO DE CORREOS
// ---------------------------------------------------------------------------

let trabajadorSeleccionadoCorreo = null;

async function abrirModalCorreo(nombreAgente) {
  const trabajador = appData.trabajadores.find(t => t.agente === nombreAgente);
  if (!trabajador) return;

  trabajadorSeleccionadoCorreo = trabajador;

  document.getElementById('modalCorreoAgente').value = trabajador.agente;
  document.getElementById('modalCorreoDestino').value = trabajador.email || '';
  document.getElementById('modalCorreoAsunto').value = `[TMO] Notificación de Rendimiento - ${trabajador.agente}`;
  document.getElementById('modalCorreoNota').value = '';
  document.getElementById('modalCorreoPlantilla').value = trabajador.clasificacion === 'APROBADO' ? 'felicitacion' : (trabajador.clasificacion === 'REQUIERE REVISIÓN' ? 'alerta' : 'desempeno');

  await actualizarPreviewCorreo();

  const modal = new bootstrap.Modal(document.getElementById('modalEnviarCorreo'));
  modal.show();
}

async function actualizarPreviewCorreo() {
  if (!trabajadorSeleccionadoCorreo) return;

  const agente = trabajadorSeleccionadoCorreo.agente;
  const plantilla = document.getElementById('modalCorreoPlantilla').value;
  const notaPersonalizada = document.getElementById('modalCorreoNota').value;

  try {
    const res = await fetch('/api/email/preview', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agente, plantilla, notaPersonalizada })
    });
    const data = await res.json();
    if (data.ok) {
      document.getElementById('modalCorreoPreview').innerHTML = data.html;
    }
  } catch (err) {
    console.error('Error generando vista previa:', err);
  }
}

async function ejecutarEnvioIndividual() {
  if (!trabajadorSeleccionadoCorreo) return;

  const btn = document.getElementById('btnConfirmarEnvioCorreo');
  const txtOriginal = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span> Enviando...`;

  const payload = {
    agente: trabajadorSeleccionadoCorreo.agente,
    emailDestino: document.getElementById('modalCorreoDestino').value.trim(),
    asunto: document.getElementById('modalCorreoAsunto').value.trim(),
    notaPersonalizada: document.getElementById('modalCorreoNota').value.trim(),
    plantilla: document.getElementById('modalCorreoPlantilla').value
  };

  try {
    const res = await fetch('/api/email/send-worker', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (data.ok) {
      bootstrap.Modal.getInstance(document.getElementById('modalEnviarCorreo')).hide();
      mostrarToast(`Correo enviado a ${payload.agente} (${payload.emailDestino})`, 'success');
      cargarHistorialCorreos();
    } else {
      mostrarToast('Error al enviar correo: ' + (data.error || 'Fallo desconocido'), 'danger');
    }
  } catch (e) {
    mostrarToast('Error en la solicitud: ' + e.message, 'danger');
  } finally {
    btn.disabled = false;
    btn.innerHTML = txtOriginal;
  }
}

async function ejecutarEnvioMasivo() {
  const criterio = document.querySelector('input[name="criterioMasivo"]:checked').value;
  const nota = document.getElementById('masivoNota').value;

  const btn = document.getElementById('btnEjecutarEnvioMasivo');
  const progreso = document.getElementById('masivoProgreso');
  btn.disabled = true;
  progreso.classList.remove('d-none');

  try {
    const res = await fetch('/api/email/send-bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ criterio, notaPersonalizada: nota })
    });
    const data = await res.json();

    if (data.ok) {
      bootstrap.Modal.getInstance(document.getElementById('modalEnvioMasivo')).hide();
      mostrarToast(`Envío masivo completado: ${data.total} correos procesados`, 'success');
      cargarHistorialCorreos();
    } else {
      mostrarToast('Fallo en envío masivo: ' + data.error, 'danger');
    }
  } catch (e) {
    mostrarToast('Error en el envío: ' + e.message, 'danger');
  } finally {
    btn.disabled = false;
    progreso.classList.add('d-none');
  }
}

async function enviarReporteSupervisor() {
  if (!confirm('¿Deseas enviar el Reporte Consolidado al Supervisor ahora?')) return;

  try {
    mostrarToast('Generando y despachando reporte al supervisor...', 'primary');
    const res = await fetch('/api/email/send-report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const data = await res.json();
    if (data.ok) {
      mostrarToast('Reporte consolidado entregado exitosamente al supervisor.', 'success');
      cargarHistorialCorreos();
    } else {
      mostrarToast('Error: ' + data.error, 'danger');
    }
  } catch (e) {
    mostrarToast('Error de comunicación: ' + e.message, 'danger');
  }
}

async function cargarHistorialCorreos() {
  try {
    const res = await fetch('/api/email/history');
    const data = await res.json();
    if (data.ok) {
      historialCorreos = data.historial || [];
      renderizarTablaBuzon();
      document.getElementById('tabCountBuzon').textContent = historialCorreos.length;
    }
  } catch (e) {
    console.error('Error cargando historial de correos:', e);
  }
}

function renderizarTablaBuzon() {
  const tbody = document.getElementById('tablaBuzonCuerpo');
  tbody.innerHTML = '';

  if (!historialCorreos.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-muted">Aún no se han enviado correos.</td></tr>`;
    return;
  }

  historialCorreos.forEach(msg => {
    const tr = document.createElement('tr');
    
    let badgeEstado = '';
    if (msg.estado === 'enviado') {
      badgeEstado = `<span class="badge bg-success-subtle text-success border border-success-subtle"><i class="bi bi-check-all"></i> Enviado SMTP</span>`;
    } else if (msg.estado === 'simulado') {
      badgeEstado = `<span class="badge bg-primary-subtle text-primary border border-primary-subtle"><i class="bi bi-inbox"></i> Buzón Web</span>`;
    } else {
      badgeEstado = `<span class="badge bg-danger-subtle text-danger border border-danger-subtle" title="${msg.error || ''}"><i class="bi bi-x-circle"></i> Error SMTP</span>`;
    }

    tr.innerHTML = `
      <td class="small text-muted">${msg.fecha || '-'}</td>
      <td><span class="badge bg-light text-dark border text-uppercase">${msg.tipo}</span></td>
      <td>
        <div class="fw-bold">${msg.agente || 'Varios'}</div>
        <div class="small text-muted">${msg.destinatario}</div>
      </td>
      <td class="fw-semibold">${msg.asunto}</td>
      <td>${badgeEstado}</td>
      <td class="text-end">
        <button class="btn btn-outline-secondary btn-sm rounded-3 btn-ver-correo" data-id="${msg.id}">
          <i class="bi bi-eye"></i> Ver Correo
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  document.querySelectorAll('.btn-ver-correo').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.dataset.id;
      const msg = historialCorreos.find(m => m.id === id);
      if (msg) abrirModalVerCorreo(msg);
    });
  });
}

function abrirModalVerCorreo(msg) {
  document.getElementById('modalVerCorreoTitulo').textContent = msg.asunto;
  document.getElementById('modalVerCorreoSubtitulo').textContent = `Destinatario: ${msg.destinatario} | ${msg.fecha}`;
  document.getElementById('verCorreoPara').textContent = `${msg.agente} (${msg.destinatario})`;
  document.getElementById('verCorreoDe').textContent = msg.remitente;
  document.getElementById('verCorreoAsunto').textContent = msg.asunto;
  document.getElementById('verCorreoEstado').textContent = msg.detalle || msg.estado;
  document.getElementById('verCorreoFecha').textContent = msg.fecha;
  document.getElementById('modalVerCorreoContenido').innerHTML = msg.html;

  new bootstrap.Modal(document.getElementById('modalVerCorreo')).show();
}

async function vaciarHistorial() {
  if (!confirm('¿Deseas vaciar todo el registro de correos enviados?')) return;
  try {
    const res = await fetch('/api/email/history', { method: 'DELETE' });
    if (res.ok) {
      historialCorreos = [];
      renderizarTablaBuzon();
      document.getElementById('tabCountBuzon').textContent = 0;
      mostrarToast('Historial de correos vaciado', 'info');
    }
  } catch (e) {
    mostrarToast('Error al vaciar historial', 'danger');
  }
}

// ---------------------------------------------------------------------------
// SUBIDA DE ARCHIVO Y GESTIÓN MANUAL
// ---------------------------------------------------------------------------

async function subirArchivo(archivo) {
  const formData = new FormData();
  formData.append('archivo', archivo);

  mostrarToast(`Procesando archivo "${archivo.name}"...`, 'primary');

  try {
    const res = await fetch('/api/upload', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    if (data.ok) {
      mostrarToast(data.mensaje, 'success');
      actualizarDatos();
    } else {
      mostrarToast('Error al procesar: ' + (data.error || 'Archivo inválido'), 'danger');
    }
  } catch (e) {
    mostrarToast('Error en la subida: ' + e.message, 'danger');
  }
}

async function cargarDatosMuestra() {
  try {
    mostrarToast('Cargando lote de prueba (76 gestiones)...', 'primary');
    const res = await fetch('/api/load-sample', { method: 'POST' });
    const data = await res.json();
    if (data.ok) {
      mostrarToast('Datos de prueba cargados correctamente.', 'success');
      actualizarDatos();
    } else {
      mostrarToast('Error: ' + data.error, 'danger');
    }
  } catch (e) {
    mostrarToast('Error: ' + e.message, 'danger');
  }
}

async function guardarGestionManual() {
  const payload = {
    agente: document.getElementById('manualAgente').value.trim(),
    tiempo: document.getElementById('manualTiempo').value,
    canal: document.getElementById('manualCanal').value,
    campania: document.getElementById('manualCampania').value.trim(),
    idGestion: document.getElementById('manualId').value.trim()
  };

  try {
    const res = await fetch('/api/gestiones/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.ok) {
      bootstrap.Modal.getInstance(document.getElementById('modalNuevaGestion')).hide();
      document.getElementById('formNuevaGestion').reset();
      mostrarToast('Gestión agregada y TMO recalculado', 'success');
      actualizarDatos();
    } else {
      mostrarToast('Error: ' + data.error, 'danger');
    }
  } catch (e) {
    mostrarToast('Error: ' + e.message, 'danger');
  }
}

async function verGestionesTrabajador(nombreAgente) {
  try {
    const res = await fetch(`/api/worker/${encodeURIComponent(nombreAgente)}/gestiones`);
    const data = await res.json();
    if (data.ok) {
      document.getElementById('modalDetalleTitulo').textContent = `Gestiones registradas para ${nombreAgente} (${data.total})`;
      const tbody = document.getElementById('tablaDetalleGestionesCuerpo');
      tbody.innerHTML = '';

      if (!data.gestiones.length) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-3 text-muted">No hay registros individuales para este asesor.</td></tr>`;
      } else {
        data.gestiones.forEach(g => {
          const colTiempo = appData.config?.columnas?.tiempo || 'Tiempo de gestión';
          const colId = appData.config?.columnas?.idGestion || 'ID Gestion';
          const colFecha = appData.config?.columnas?.fecha || 'Fecha';
          const colCanal = appData.config?.columnas?.canal || 'Canal';
          const colCamp = appData.config?.columnas?.campania || 'Campaña';

          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td><code>${g[colId] || g['ID Gestion'] || '-'}</code></td>
            <td class="fw-bold">${g[colTiempo] || g['Tiempo de gestión'] || '-'}</td>
            <td class="small text-muted">${g[colFecha] || g.Fecha || '-'}</td>
            <td><span class="badge bg-light text-dark border">${g[colCanal] || g.Canal || 'Voz'}</span></td>
            <td>${g[colCamp] || g['Campaña'] || '-'}</td>
          `;
          tbody.appendChild(tr);
        });
      }

      new bootstrap.Modal(document.getElementById('modalDetalleAgente')).show();
    }
  } catch (e) {
    mostrarToast('Error obteniendo gestiones: ' + e.message, 'danger');
  }
}

// ---------------------------------------------------------------------------
// CONFIGURACIÓN Y SMTP
// ---------------------------------------------------------------------------

function cargarConfiguracionEnModal(cfg) {
  if (!cfg) return;
  document.getElementById('cfgTmoLimite').value = cfg.tmoLimite || 20;
  document.getElementById('cfgTimezone').value = cfg.timezone || 'America/Bogota';

  if (cfg.modoEnvio === 'smtp') {
    document.getElementById('modoSmtp').checked = true;
    document.getElementById('seccionSmtpCampos').classList.remove('d-none');
  } else {
    document.getElementById('modoSimulacion').checked = true;
    document.getElementById('seccionSmtpCampos').classList.add('d-none');
  }

  document.getElementById('cfgSmtpHost').value = cfg.smtpHost || '';
  document.getElementById('cfgSmtpPort').value = cfg.smtpPort || 2525;
  document.getElementById('cfgSmtpUser').value = cfg.smtpUser || '';
  document.getElementById('cfgSmtpPass').value = cfg.smtpPass || '';
  document.getElementById('cfgSmtpSecure').checked = Boolean(cfg.smtpSecure);

  document.getElementById('cfgRemitente').value = cfg.correo?.remitente || '';
  document.getElementById('cfgSupervisor').value = cfg.correo?.destinoReporte || '';
}

async function guardarLimiteTmo(nuevoLimite) {
  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tmoLimite: nuevoLimite })
    });
    const data = await res.json();
    if (data.ok) {
      mostrarToast(`Meta de TMO ajustada a ${nuevoLimite} segundos. Recalculado.`, 'success');
      actualizarDatos();
    }
  } catch (e) {
    mostrarToast('Error actualizando límite: ' + e.message, 'danger');
  }
}

async function guardarConfiguracionCompleta() {
  const modoEnvio = document.querySelector('input[name="cfgModoEnvio"]:checked').value;
  const payload = {
    tmoLimite: Number(document.getElementById('cfgTmoLimite').value),
    timezone: document.getElementById('cfgTimezone').value,
    modoEnvio,
    smtpHost: document.getElementById('cfgSmtpHost').value.trim(),
    smtpPort: Number(document.getElementById('cfgSmtpPort').value),
    smtpUser: document.getElementById('cfgSmtpUser').value.trim(),
    smtpPass: document.getElementById('cfgSmtpPass').value,
    smtpSecure: document.getElementById('cfgSmtpSecure').checked,
    emailRemitente: document.getElementById('cfgRemitente').value.trim(),
    emailSupervisor: document.getElementById('cfgSupervisor').value.trim()
  };

  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.ok) {
      bootstrap.Modal.getInstance(document.getElementById('modalConfiguracion')).hide();
      mostrarToast('Configuración guardada exitosamente.', 'success');
      actualizarDatos();
    } else {
      mostrarToast('Error al guardar configuración: ' + (data.errores || data.error), 'danger');
    }
  } catch (e) {
    mostrarToast('Error en la solicitud: ' + e.message, 'danger');
  }
}

async function probarSmtp() {
  const resLabel = document.getElementById('testSmtpResultado');
  resLabel.className = 'small ms-2 text-primary';
  resLabel.textContent = 'Probando conexión...';

  const payload = {
    host: document.getElementById('cfgSmtpHost').value.trim(),
    port: Number(document.getElementById('cfgSmtpPort').value),
    secure: document.getElementById('cfgSmtpSecure').checked,
    user: document.getElementById('cfgSmtpUser').value.trim(),
    pass: document.getElementById('cfgSmtpPass').value
  };

  try {
    const res = await fetch('/api/email/test-smtp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.ok) {
      resLabel.className = 'small ms-2 text-success fw-bold';
      resLabel.textContent = '✅ Conexión SMTP Exitosa!';
    } else {
      resLabel.className = 'small ms-2 text-danger';
      resLabel.textContent = '❌ Error: ' + (data.error || 'No se pudo conectar');
    }
  } catch (e) {
    resLabel.className = 'small ms-2 text-danger';
    resLabel.textContent = '❌ Error de red: ' + e.message;
  }
}
