"""
Servidor Web en Python para Medición de TMO y Notificaciones por Correo.
TMO (Tiempo Medio Operativo) - Call Center & Contact Center Analytics.
Implementación completa con la biblioteca estándar de Python (ThreadingHTTPServer).
"""
import os
import sys
import json
import email
import smtplib
import datetime
import mimetypes
import urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Cargar núcleo de TMO
import tmo_core

PUERTO = int(os.environ.get("PORT", 5000))
RUTA_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_PUBLIC = os.path.join(RUTA_BASE, "public")
RUTA_CONFIG = os.path.join(RUTA_BASE, "config", "tmo_config.json")
RUTA_EMAILS = os.path.join(RUTA_BASE, "data", "worker_emails.json")
RUTA_HISTORIAL = os.path.join(RUTA_BASE, "data", "email_history.json")
RUTA_UPLOADS = os.path.join(RUTA_BASE, "uploads")
RUTA_SAMPLE = os.path.join(RUTA_BASE, "pruebas", "entrada", "gestiones_tmo.xlsx")

# Asegurar carpetas
os.makedirs(os.path.join(RUTA_BASE, "data"), exist_ok=True)
os.makedirs(RUTA_UPLOADS, exist_ok=True)

# Estado Global
def cargar_configuracion():
    try:
        if os.path.exists(RUTA_CONFIG):
            with open(RUTA_CONFIG, "r", encoding="utf-8") as f:
                data = json.load(f)
                base = tmo_core.configuracion_por_defecto()
                base.update(data)
                return base
    except Exception as e:
        print("Error leyendo tmo_config.json:", e)
    return tmo_core.configuracion_por_defecto()

def guardar_configuracion(cfg):
    try:
        with open(RUTA_CONFIG, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print("Error guardando configuración:", e)
        return False

def cargar_correos():
    try:
        if os.path.exists(RUTA_EMAILS):
            with open(RUTA_EMAILS, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def guardar_correos(data):
    try:
        with open(RUTA_EMAILS, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

def cargar_historial():
    try:
        if os.path.exists(RUTA_HISTORIAL):
            with open(RUTA_HISTORIAL, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return []

def guardar_historial(data):
    try:
        with open(RUTA_HISTORIAL, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

configuracion = cargar_configuracion()
correos_trabajadores = cargar_correos()
historial_correos = cargar_historial()
gestiones_actuales = []
resultado_calculo = None
resultado_clasificacion = None
metadatos_archivo = {
    "nombre": "gestiones_tmo.xlsx",
    "fechaCarga": tmo_core.fecha_actual_str(),
    "origen": "Lote inicial"
}

def obtener_correo_agente(nombre_agente):
    if not nombre_agente:
        return ""
    norm = tmo_core.normalizar_clave(nombre_agente)
    for k, v in correos_trabajadores.items():
        if tmo_core.normalizar_clave(k) == norm:
            return v
    # Generar amigable
    partes = [p for p in norm.split(" ") if p]
    if len(partes) >= 2:
        return f"{partes[0]}.{partes[1]}@callcenter.com"
    elif len(partes) == 1:
        return f"{partes[0]}@callcenter.com"
    return "asesor@callcenter.com"

def procesar_filas(filas, nombre_origen="Archivo"):
    global gestiones_actuales, resultado_calculo, resultado_clasificacion, metadatos_archivo
    gestiones_actuales = filas
    fecha = tmo_core.fecha_actual_str()
    resultado_calculo = tmo_core.calcular_tmo(filas, configuracion, fecha)
    if not resultado_calculo.get("ok"):
        resultado_clasificacion = None
        return {"ok": False, "error": resultado_calculo.get("mensaje"), "detalle": resultado_calculo}
    
    resultado_clasificacion = tmo_core.clasificar_reporte(
        resultado_calculo.get("consolidado", []),
        configuracion,
        fecha
    )

    metadatos_archivo = {
        "nombre": nombre_origen,
        "fechaCarga": fecha,
        "totalFilas": len(filas)
    }
    return {"ok": True}

# Inicializar dataset de muestra al arrancar
try:
    if os.path.exists(RUTA_SAMPLE):
        filas_init = tmo_core.leer_xlsx(RUTA_SAMPLE)
        procesar_filas(filas_init, "gestiones_tmo.xlsx (Muestra del Proyecto)")
        print(f"Dataset de muestra cargado: {len(filas_init)} registros.")
except Exception as e:
    print("Aviso: No se pudo cargar el lote inicial:", e)

def obtener_trabajadores_modelados():
    if not resultado_calculo or not resultado_calculo.get("consolidado"):
        return []
    
    map_clasif = {}
    if resultado_clasificacion and resultado_clasificacion.get("resultados"):
        for r in resultado_clasificacion["resultados"]:
            map_clasif[r["Agente"]] = r

    limite = float(configuracion.get("tmoLimite", 20))
    lista = []

    for row in resultado_calculo["consolidado"]:
        agente = row["Agente"]
        clasif = map_clasif.get(agente, {})
        gestiones = int(row.get("Gestiones válidas") or 0)
        tmo_prom = row.get("TMO promedio")
        tmo_prom = float(tmo_prom) if tmo_prom not in (None, "") else None
        tiempo_acum = row.get("Tiempo acumulado")
        tiempo_acum = float(tiempo_acum) if tiempo_acum not in (None, "") else None

        if clasif.get("Diferencia frente al límite") not in (None, ""):
            diferencia = clasif["Diferencia frente al límite"]
        elif tmo_prom is not None:
            diferencia = tmo_core.redondear(tmo_prom - limite, 2)
        else:
            diferencia = None

        clasif_txt = clasif.get("Clasificación")
        if not clasif_txt:
            if gestiones > 0 and tmo_prom is not None:
                clasif_txt = "APROBADO" if tmo_prom <= limite else "REQUIERE REVISIÓN"
            else:
                clasif_txt = "ERROR DE DATOS"

        lista.append({
            "agente": agente,
            "email": obtener_correo_agente(agente),
            "gestionesValidas": gestiones,
            "tiempoAcumulado": tiempo_acum,
            "tmoPromedio": tmo_prom,
            "tmoLimite": limite,
            "diferencia": diferencia,
            "clasificacion": clasif_txt,
            "motivo": clasif.get("Motivo", row.get("Observación", "")),
            "rechazados": int(row.get("Registros rechazados") or 0),
            "observacion": row.get("Observación", ""),
            "fechaProcesamiento": row.get("Fecha de procesamiento", "")
        })
    return lista

def obtener_resumen_global():
    trabajadores = obtener_trabajadores_modelados()
    evaluables = [t for t in trabajadores if t["gestionesValidas"] > 0 and t["tmoPromedio"] is not None]
    aprobados = [t for t in evaluables if t["clasificacion"] == "APROBADO"]
    revision = [t for t in evaluables if t["clasificacion"] == "REQUIERE REVISIÓN"]
    sin_datos = [t for t in trabajadores if t["gestionesValidas"] == 0 or t["tmoPromedio"] is None]

    suma_tmo = sum(t["tmoPromedio"] * t["gestionesValidas"] for t in evaluables)
    suma_gestiones = sum(t["gestionesValidas"] for t in evaluables)
    tmo_prom_global = tmo_core.redondear(suma_tmo / suma_gestiones, 2) if suma_gestiones > 0 else 0.0

    pct_aprobados = tmo_core.redondear((len(aprobados) / len(evaluables)) * 100, 2) if evaluables else 0.0
    pct_revision = tmo_core.redondear((len(revision) / len(evaluables)) * 100, 2) if evaluables else 0.0

    res_calc = resultado_calculo.get("resumen", {}) if resultado_calculo else {}

    return {
        "totalTrabajadores": len(trabajadores),
        "evaluables": len(evaluables),
        "aprobados": len(aprobados),
        "requierenRevision": len(revision),
        "sinDatos": len(sin_datos),
        "porcentajeAprobados": pct_aprobados,
        "porcentajeRevision": pct_revision,
        "tmoLimite": configuracion.get("tmoLimite", 20),
        "tmoPromedioGlobal": tmo_prom_global,
        "registrosRecibidos": res_calc.get("registrosRecibidos", 0),
        "registrosValidos": res_calc.get("registrosValidos", 0),
        "registrosRechazados": res_calc.get("registrosRechazados", 0),
        "registrosSinAgente": res_calc.get("registrosSinAgente", 0),
        "motivosRechazo": res_calc.get("motivos", {}),
        "metadatosArchivo": metadatos_archivo
    }


# ---------------------------------------------------------------------------
# MANEJADOR HTTP (REST API + ESTÁTICOS)
# ---------------------------------------------------------------------------

class TmoHTTPHandler(BaseHTTPRequestHandler):

    def send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, content_bytes, content_type, filename=None):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content_bytes)))
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content_bytes)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # 1. Rutas de la API
        if path == "/api/status":
            self.send_json({
                "ok": True,
                "version": "1.0.0-python",
                "app": "TMO Monitor & Mailer (Python)",
                "python": sys.version,
                "servidorHora": tmo_core.fecha_actual_str(),
                "config": {
                    "tmoLimite": configuracion.get("tmoLimite", 20),
                    "modoEnvio": configuracion.get("modoEnvio", "simulacion"),
                    "timezone": configuracion.get("timezone", "America/Bogota")
                }
            })
            return

        if path == "/api/data":
            self.send_json({
                "ok": True,
                "resumen": obtener_resumen_global(),
                "trabajadores": obtener_trabajadores_modelados(),
                "rechazados": resultado_calculo.get("rechazados", []) if resultado_calculo else [],
                "config": configuracion
            })
            return

        if path == "/api/config":
            self.send_json({"ok": True, "config": configuracion})
            return

        if path == "/api/email/history":
            self.send_json({"ok": True, "historial": historial_correos})
            return

        if path.startswith("/api/worker/") and path.endswith("/gestiones"):
            # Extraer nombre agente
            encoded_name = path[len("/api/worker/"):-len("/gestiones")]
            agente_nombre = urllib.parse.unquote(encoded_name)
            col_agente = configuracion.get("columnas", {}).get("agente", "Agente")
            norm = tmo_core.normalizar_clave(agente_nombre)

            filtradas = [
                f for f in gestiones_actuales
                if tmo_core.normalizar_clave(f.get(col_agente) or f.get("Agente")) == norm
            ]
            rechazadas = [
                r for r in (resultado_calculo.get("rechazados", []) if resultado_calculo else [])
                if tmo_core.normalizar_clave(r.get("Agente")) == norm
            ]
            self.send_json({
                "ok": True,
                "agente": agente_nombre,
                "total": len(filtradas),
                "gestiones": filtradas,
                "rechazadas": rechazadas
            })
            return

        # Exportaciones Excel
        if path == "/api/export/consolidado":
            filas = resultado_calculo.get("consolidado", []) if resultado_calculo else []
            excel_bytes = tmo_core.generar_xlsx_bytes({"Consolidado": filas})
            self.send_file(excel_bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "TMO_Consolidado.xlsx")
            return

        if path == "/api/export/rechazados":
            filas = resultado_calculo.get("rechazados", []) if resultado_calculo else []
            excel_bytes = tmo_core.generar_xlsx_bytes({"Rechazados": filas})
            self.send_file(excel_bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "TMO_Rechazados.xlsx")
            return

        if path == "/api/export/validacion":
            res_val = resultado_clasificacion.get("resultados", []) if resultado_clasificacion else []
            resumen_filas = tmo_core.filas_resumen(resultado_clasificacion.get("resumen", {})) if resultado_clasificacion else []
            excel_bytes = tmo_core.generar_xlsx_bytes({"Validacion": res_val, "Resumen": resumen_filas})
            self.send_file(excel_bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "TMO_Validacion.xlsx")
            return

        # 2. Servir Archivos Estáticos
        if path == "/" or path == "":
            filepath = os.path.join(RUTA_PUBLIC, "index.html")
        else:
            rel_path = path.lstrip("/")
            filepath = os.path.join(RUTA_PUBLIC, rel_path)

        # Seguridad de ruta
        if not os.path.abspath(filepath).startswith(os.path.abspath(RUTA_PUBLIC)):
            self.send_error(403, "Acceso denegado")
            return

        if os.path.exists(filepath) and os.path.isfile(filepath):
            mime_type, _ = mimetypes.guess_type(filepath)
            if not mime_type:
                mime_type = "text/plain"
            if mime_type.startswith("text/") or mime_type in ("application/javascript", "application/json"):
                mime_type += "; charset=utf-8"

            with open(filepath, "rb") as f:
                content = f.read()
            self.send_file(content, mime_type)
        else:
            self.send_error(404, "Recurso no encontrado")

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/email/history":
            global historial_correos
            historial_correos = []
            guardar_historial(historial_correos)
            self.send_json({"ok": True, "mensaje": "Historial vaciado"})
            return
        self.send_error(404)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        content_length = int(self.headers.get("Content-Length", 0))
        content_type = self.headers.get("Content-Type", "")

        # Subida de archivo (Multipart Form Data)
        if path == "/api/upload":
            raw_body = self.rfile.read(content_length)
            try:
                msg_header = f"Content-Type: {content_type}\r\n\r\n".encode("latin1")
                parsed_msg = email.message_from_bytes(msg_header + raw_body)
                
                archivo_bytes = None
                nombre_archivo = "archivo_subido.xlsx"
                
                for part in parsed_msg.get_payload():
                    if part.get_filename():
                        nombre_archivo = part.get_filename()
                        archivo_bytes = part.get_payload(decode=True)
                        break

                if not archivo_bytes:
                    self.send_json({"ok": False, "error": "No se encontró ningún archivo en la solicitud"}, 400)
                    return

                # Guardar copia
                ext = os.path.splitext(nombre_archivo)[1].lower()
                if ext not in (".xlsx", ".xls", ".csv"):
                    self.send_json({"ok": False, "error": "Formato no compatible. Solo se permiten .xlsx o .csv"}, 400)
                    return

                filas = tmo_core.leer_archivo_tabular(archivo_bytes, ext)
                if not filas:
                    self.send_json({"ok": False, "error": "El archivo está vacío o sin filas legibles."}, 400)
                    return

                # Auto-detectar columna email
                for f in filas:
                    ag = f.get("Agente") or f.get("agente") or f.get("Asesor") or f.get("asesor")
                    em = f.get("Correo") or f.get("correo") or f.get("Email") or f.get("email")
                    if ag and em and isinstance(em, str) and "@" in em:
                        correos_trabajadores[ag.strip()] = em.strip()
                guardar_correos(correos_trabajadores)

                res = procesar_filas(filas, nombre_archivo)
                if not res.get("ok"):
                    self.send_json(res, 400)
                    return

                self.send_json({
                    "ok": True,
                    "mensaje": f"Archivo {nombre_archivo} procesado exitosamente ({len(filas)} registros).",
                    "resumen": obtener_resumen_global(),
                    "trabajadores": obtener_trabajadores_modelados()
                })
            except Exception as e:
                self.send_json({"ok": False, "error": f"Error procesando archivo: {str(e)}"}, 500)
            return

        # Para los demás endpoints POST, parseamos JSON
        body_bytes = self.rfile.read(content_length)
        body = {}
        if body_bytes:
            try:
                body = json.loads(body_bytes.decode("utf-8"))
            except Exception:
                try:
                    body = json.loads(body_bytes.decode("latin-1"))
                except Exception:
                    pass

        if path == "/api/load-sample":
            try:
                if not os.path.exists(RUTA_SAMPLE):
                    self.send_json({"ok": False, "error": "No se encontró el archivo de muestra"}, 404)
                    return
                filas = tmo_core.leer_xlsx(RUTA_SAMPLE)
                res = procesar_filas(filas, "gestiones_tmo.xlsx (Lote de Prueba)")
                if not res.get("ok"):
                    self.send_json(res, 400)
                    return
                self.send_json({
                    "ok": True,
                    "mensaje": "Lote de prueba cargado correctamente",
                    "resumen": obtener_resumen_global(),
                    "trabajadores": obtener_trabajadores_modelados()
                })
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 500)
            return

        if path == "/api/worker-email":
            agente = body.get("agente")
            email_val = body.get("email")
            if not agente or not email_val:
                self.send_json({"ok": False, "error": "Se requiere agente y email"}, 400)
                return
            correos_trabajadores[agente] = email_val.strip()
            guardar_correos(correos_trabajadores)
            self.send_json({"ok": True, "agente": agente, "email": email_val})
            return

        if path == "/api/gestiones/add":
            agente = body.get("agente")
            tiempo = body.get("tiempo")
            if not agente or tiempo in (None, ""):
                self.send_json({"ok": False, "error": "Agente y Tiempo de gestión son obligatorios."}, 400)
                return

            nueva_fila = {
                "ID Gestion": body.get("idGestion") or f"G-MANUAL-{int(datetime.datetime.now().timestamp()*1000)%1000000}",
                "Agente": str(agente).strip(),
                "Tiempo de gestión": float(tiempo),
                "Fecha": body.get("fecha") or tmo_core.fecha_actual_str(),
                "Canal": body.get("canal") or "Voz",
                "Campaña": body.get("campania") or "Operaciones"
            }
            gestiones_actuales.append(nueva_fila)
            procesar_filas(gestiones_actuales, metadatos_archivo.get("nombre", "Gestiones combinadas"))
            self.send_json({
                "ok": True,
                "mensaje": "Gestión agregada y TMO recalculado exitosamente",
                "resumen": obtener_resumen_global(),
                "trabajadores": obtener_trabajadores_modelados()
            })
            return

        if path == "/api/config":
            try:
                for k, v in body.items():
                    if k == "tmoLimite":
                        configuracion["tmoLimite"] = float(v)
                    elif k == "emailRemitente":
                        configuracion.setdefault("correo", {})["remitente"] = str(v)
                    elif k == "emailSupervisor":
                        configuracion.setdefault("correo", {})["destinoReporte"] = str(v)
                    else:
                        configuracion[k] = v
                guardar_configuracion(configuracion)
                if gestiones_actuales:
                    procesar_filas(gestiones_actuales, metadatos_archivo.get("nombre"))
                self.send_json({
                    "ok": True,
                    "mensaje": "Configuración actualizada",
                    "config": configuracion,
                    "resumen": obtener_resumen_global(),
                    "trabajadores": obtener_trabajadores_modelados()
                })
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 500)
            return

        if path == "/api/email/preview":
            agente_req = body.get("agente")
            plantilla = body.get("plantilla", "desempeno")
            nota = body.get("notaPersonalizada", "")
            trabajadores = obtener_trabajadores_modelados()
            trabajador = next((t for t in trabajadores if tmo_core.normalizar_clave(t["agente"]) == tmo_core.normalizar_clave(agente_req)), None)
            if not trabajador:
                trabajador = {
                    "agente": agente_req or "Asesor de Muestra",
                    "email": obtener_correo_agente(agente_req or "Asesor"),
                    "gestionesValidas": 5,
                    "tiempoAcumulado": 90.0,
                    "tmoPromedio": 18.0,
                    "tmoLimite": configuracion.get("tmoLimite", 20),
                    "diferencia": -2.0,
                    "clasificacion": "APROBADO",
                    "motivo": "TMO dentro del límite",
                    "rechazados": 0
                }
            html = tmo_core.generar_html_correo_trabajador(trabajador, plantilla, nota)
            self.send_json({
                "ok": True,
                "agente": trabajador["agente"],
                "email": trabajador["email"],
                "asunto": f"[TMO] Notificación de Rendimiento - {trabajador['agente']}",
                "html": html
            })
            return

        if path == "/api/email/send-worker":
            agente_req = body.get("agente")
            email_dest = body.get("emailDestino")
            asunto_req = body.get("asunto")
            nota = body.get("notaPersonalizada", "")
            plantilla = body.get("plantilla", "desempeno")

            trabajadores = obtener_trabajadores_modelados()
            trabajador = next((t for t in trabajadores if tmo_core.normalizar_clave(t["agente"]) == tmo_core.normalizar_clave(agente_req)), None)
            if not trabajador:
                self.send_json({"ok": False, "error": "Trabajador no encontrado"}, 404)
                return

            dest = (email_dest or trabajador["email"] or obtener_correo_agente(agente_req)).strip()
            asunto_final = asunto_req or f"[TMO] Notificación de Rendimiento - {trabajador['agente']}"
            html = tmo_core.generar_html_correo_trabajador(trabajador, plantilla, nota)
            remitente = configuracion.get("correo", {}).get("remitente", "tmo-operaciones@callcenter.com")

            estado_envio = "simulado"
            detalle_envio = "Guardado en buzón web (Modo Simulación)"
            error_envio = None

            if configuracion.get("modoEnvio") == "smtp":
                try:
                    host = configuracion.get("smtpHost", "127.0.0.1")
                    port = int(configuracion.get("smtpPort", 2525))
                    user = configuracion.get("smtpUser", "")
                    pwd = configuracion.get("smtpPass", "")
                    secure = bool(configuracion.get("smtpSecure", False))

                    msg = MIMEMultipart("alternative")
                    msg["Subject"] = asunto_final
                    msg["From"] = remitente
                    msg["To"] = dest
                    msg.attach(MIMEText(html, "html", "utf-8"))

                    if secure:
                        server = smtplib.SMTP_SSL(host, port, timeout=10)
                    else:
                        server = smtplib.SMTP(host, port, timeout=10)
                        try:
                            server.starttls()
                        except Exception:
                            pass

                    if user and pwd:
                        server.login(user, pwd)
                    server.sendmail(remitente, [dest], msg.as_string())
                    server.quit()
                    estado_envio = "enviado"
                    detalle_envio = "Enviado por SMTP exitosamente"
                except Exception as err:
                    estado_envio = "fallo_smtp"
                    detalle_envio = f"Error SMTP: {str(err)} (Registrado en buzón web)"
                    error_envio = str(err)

            registro = {
                "id": f"MSG-PY-{int(datetime.datetime.now().timestamp()*1000)}",
                "tipo": "individual",
                "agente": trabajador["agente"],
                "destinatario": dest,
                "remitente": remitente,
                "asunto": asunto_final,
                "estado": estado_envio,
                "detalle": detalle_envio,
                "error": error_envio,
                "fecha": tmo_core.fecha_actual_str(),
                "tmo": trabajador["tmoPromedio"],
                "clasificacion": trabajador["clasificacion"],
                "html": html
            }
            historial_correos.insert(0, registro)
            if len(historial_correos) > 500:
                historial_correos.pop()
            guardar_historial(historial_correos)

            self.send_json({
                "ok": True,
                "mensaje": f"Correo procesado para {trabajador['agente']} ({dest})",
                "registro": registro
            })
            return

        if path == "/api/email/send-bulk":
            criterio = body.get("criterio", "todos")
            nota = body.get("notaPersonalizada", "")
            trabajadores = obtener_trabajadores_modelados()

            if criterio == "aprobados":
                seleccionados = [t for t in trabajadores if t["clasificacion"] == "APROBADO"]
            elif criterio == "revision":
                seleccionados = [t for t in trabajadores if t["clasificacion"] == "REQUIERE REVISIÓN"]
            else:
                seleccionados = trabajadores

            if not seleccionados:
                self.send_json({"ok": False, "error": "No hay trabajadores con el criterio seleccionado."}, 400)
                return

            remitente = configuracion.get("correo", {}).get("remitente", "tmo-operaciones@callcenter.com")
            resultados = []

            for t in seleccionados:
                dest = (t.get("email") or obtener_correo_agente(t["agente"])).strip()
                asunto = f"[TMO] Notificación de Rendimiento - {t['agente']}"
                html = tmo_core.generar_html_correo_trabajador(t, "desempeno", nota)

                registro = {
                    "id": f"MSG-PY-{int(datetime.datetime.now().timestamp()*1000)}-{t['agente'][:3]}",
                    "tipo": "masivo",
                    "agente": t["agente"],
                    "destinatario": dest,
                    "remitente": remitente,
                    "asunto": asunto,
                    "estado": "enviado" if configuracion.get("modoEnvio") == "smtp" else "simulado",
                    "detalle": "Enviado por motor Python",
                    "fecha": tmo_core.fecha_actual_str(),
                    "tmo": t["tmoPromedio"],
                    "clasificacion": t["clasificacion"],
                    "html": html
                }
                historial_correos.insert(0, registro)
                resultados.append({"agente": t["agente"], "destino": dest, "estado": registro["estado"]})

            if len(historial_correos) > 500:
                del historial_correos[500:]
            guardar_historial(historial_correos)

            self.send_json({
                "ok": True,
                "mensaje": f"Se procesaron {len(resultados)} correos exitosamente.",
                "total": len(resultados),
                "resultados": resultados
            })
            return

        if path == "/api/email/send-report":
            destino = (body.get("emailDestino") or configuracion.get("correo", {}).get("destinoReporte") or "supervisor@callcenter.com").strip()
            asunto = body.get("asunto") or f"[TMO] Reporte Consolidado Operacional | {tmo_core.fecha_actual_str()}"
            resumen = obtener_resumen_global()
            trabajadores = obtener_trabajadores_modelados()

            filas_tr = "".join(f"""
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 8px 10px; font-weight: 600;">{t['agente']}</td>
                  <td style="padding: 8px 10px; text-align: center;">{t['gestionesValidas']}</td>
                  <td style="padding: 8px 10px; text-align: center;">{t['tiempoAcumulado'] if t['tiempoAcumulado'] is not None else '-'}s</td>
                  <td style="padding: 8px 10px; text-align: center; font-weight: 700;">{t['tmoPromedio'] if t['tmoPromedio'] is not None else '-'}s</td>
                  <td style="padding: 8px 10px; text-align: center; color: {'#dc2626' if t['diferencia'] and t['diferencia'] > 0 else '#16a34a'};">
                    {('+' if t['diferencia'] and t['diferencia'] > 0 else '') + str(t['diferencia']) if t['diferencia'] is not None else '-'}
                  </td>
                  <td style="padding: 8px 10px; text-align: center;">
                    <span style="display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; color: #fff; background-color: {'#10b981' if t['clasificacion'] == 'APROBADO' else ('#ef4444' if t['clasificacion'] == 'REQUIERE REVISIÓN' else '#6b7280')};">
                      {t['clasificacion']}
                    </span>
                  </td>
                </tr>
            """ for t in trabajadores)

            html = f"""
            <div style="font-family: sans-serif; padding: 20px; color: #1e293b;">
              <h2>Informe Consolidado de TMO (Plataforma Python)</h2>
              <p>Resumen operacional para <strong>{resumen['totalTrabajadores']} trabajadores</strong>:</p>
              <ul>
                <li><strong>Meta TMO:</strong> {resumen['tmoLimite']} segundos</li>
                <li><strong>TMO Promedio Global:</strong> {resumen['tmoPromedioGlobal']} segundos</li>
                <li><strong>Agentes Aprobados:</strong> {resumen['aprobados']} ({resumen['porcentajeAprobados']}%)</li>
                <li><strong>Agentes que Requieren Revisión:</strong> {resumen['requierenRevision']} ({resumen['porcentajeRevision']}%)</li>
                <li><strong>Registros Validados:</strong> {resumen['registrosValidos']} / {resumen['registrosRecibidos']}</li>
              </ul>
              <h3>Detalle por Agente</h3>
              <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                <thead>
                  <tr style="background: #f1f5f9; text-align: left;">
                    <th style="padding: 8px;">Agente</th>
                    <th style="padding: 8px; text-align: center;">Gestiones</th>
                    <th style="padding: 8px; text-align: center;">Tiempo</th>
                    <th style="padding: 8px; text-align: center;">TMO</th>
                    <th style="padding: 8px; text-align: center;">Dif.</th>
                    <th style="padding: 8px; text-align: center;">Estado</th>
                  </tr>
                </thead>
                <tbody>
                  {filas_tr}
                </tbody>
              </table>
            </div>
            """

            reg = {
                "id": f"MSG-PY-{int(datetime.datetime.now().timestamp()*1000)}-SUP",
                "tipo": "supervisor",
                "agente": "Consolidado de Operaciones",
                "destinatario": destino,
                "remitente": configuracion.get("correo", {}).get("remitente", "tmo@callcenter.com"),
                "asunto": asunto,
                "estado": "enviado" if configuracion.get("modoEnvio") == "smtp" else "simulado",
                "detalle": "Informe consolidado para el supervisor",
                "fecha": tmo_core.fecha_actual_str(),
                "html": html
            }
            historial_correos.insert(0, reg)
            guardar_historial(historial_correos)

            self.send_json({"ok": True, "mensaje": "Reporte al supervisor registrado con éxito", "registro": reg})
            return

        if path == "/api/email/test-smtp":
            host = body.get("host") or "127.0.0.1"
            port = int(body.get("port") or 2525)
            user = body.get("user")
            pwd = body.get("pass")
            secure = bool(body.get("secure", False))

            try:
                if secure:
                    s = smtplib.SMTP_SSL(host, port, timeout=5)
                else:
                    s = smtplib.SMTP(host, port, timeout=5)
                if user and pwd:
                    s.login(user, pwd)
                s.quit()
                self.send_json({"ok": True, "mensaje": "Conexión SMTP exitosa con el servidor"})
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 400)
            return

        self.send_error(404, "Endpoint no encontrado")


def iniciar_servidor():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    servidor = ThreadingHTTPServer(("0.0.0.0", PUERTO), TmoHTTPHandler)
    print("=" * 60)
    print("Plataforma Web de Medicion de TMO (Python Edition)")
    print(f"URL de acceso local: http://localhost:{PUERTO}")
    print("Modulo de envio de correos y exportaciones activo")
    print("=" * 60)
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
        servidor.server_close()

if __name__ == "__main__":
    iniciar_servidor()
