"""
Núcleo de cálculo y auditoría de TMO (Tiempo Medio Operativo) en Python.
Implementación pura sin dependencias externas obligatorias.
"""
import re
import math
import unicodedata
import datetime
import zipfile
import xml.etree.ElementTree as ET
import io
import csv

COLUMNAS_CONSOLIDADO = [
    'Agente',
    'Gestiones válidas',
    'Tiempo acumulado',
    'TMO promedio',
    'Registros rechazados',
    'Fecha de procesamiento',
    'Observación'
]

COLUMNAS_RECHAZADOS = [
    'Fila origen',
    'ID Gestion',
    'Agente',
    'Tiempo de gestión',
    'Fecha',
    'Canal',
    'Campaña',
    'Motivo rechazo',
    'Fecha de procesamiento'
]

COLUMNAS_VALIDACION = [
    'Agente',
    'Gestiones válidas',
    'TMO promedio',
    'TMO límite',
    'Diferencia frente al límite',
    'Clasificación',
    'Motivo',
    'Fecha de validación'
]


def normalizar_clave(valor) -> str:
    if valor is None:
        return ""
    texto = str(valor)
    # Quitar acentos/tildes
    texto = unicodedata.normalize('NFD', texto)
    texto = "".join(c for c in texto if unicodedata.category(c) != 'Mn')
    texto = texto.lower()
    texto = re.sub(r'\s+', ' ', texto).strip()
    return texto


def texto_plano(valor) -> str:
    if valor is None:
        return ""
    return re.sub(r'\s+', ' ', str(valor)).strip()


def redondear(numero, decimales=2):
    if numero is None or not isinstance(numero, (int, float)) or math.isnan(numero) or math.isinf(numero):
        return None
    factor = 10 ** decimales
    return round(numero + 1e-15, decimales)


def fecha_actual_str(time_zone_offset_hours=-5) -> str:
    """Retorna fecha legible YYYY-MM-DD HH:MM:SS en horario especificado (default Colombia/Bogotá UTC-5)"""
    tz = datetime.timezone(datetime.timedelta(hours=time_zone_offset_hours))
    ahora = datetime.datetime.now(tz)
    return ahora.strftime('%Y-%m-%d %H:%M:%S')


def parsear_tiempo(valor):
    if valor is None:
        return False, "Tiempo de gestión vacío", None
    if isinstance(valor, (int, float)):
        if math.isnan(valor) or math.isinf(valor):
            return False, "Tiempo de gestión no numérico", None
        if valor < 0:
            return False, "Tiempo de gestión negativo", None
        return True, None, float(valor)
    
    texto = str(valor).strip()
    if not texto:
        return False, "Tiempo de gestión vacío", None
    
    normalizado = texto.replace(',', '.')
    if not re.match(r'^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$', normalizado):
        return False, "Tiempo de gestión con formato incorrecto", None
    
    try:
        numero = float(normalizado)
        if math.isnan(numero) or math.isinf(numero):
            return False, "Tiempo de gestión no numérico", None
        if numero < 0:
            return False, "Tiempo de gestión negativo", None
        return True, None, numero
    except ValueError:
        return False, "Tiempo de gestión no numérico", None


def configuracion_por_defecto():
    return {
        "tmoLimite": 20,
        "timezone": "America/Bogota",
        "hojaEntrada": "Gestiones",
        "hojaConsolidado": "Consolidado",
        "politicaDuplicados": "omitir",
        "minutosBloqueoEnProceso": 15,
        "modoEnvio": "simulacion",
        "smtpHost": "127.0.0.1",
        "smtpPort": 2525,
        "smtpSecure": False,
        "smtpUser": "",
        "smtpPass": "",
        "columnas": {
            "agente": "Agente",
            "tiempo": "Tiempo de gestión",
            "idGestion": "ID Gestion",
            "fecha": "Fecha",
            "canal": "Canal",
            "campania": "Campaña"
        },
        "correo": {
            "remitente": "tmo-operaciones@callcenter.com",
            "destinoReporte": "supervisor-tmo@callcenter.com",
            "destinoAprobados": "tmo-aprobados@callcenter.com",
            "destinoNovedades": "tmo-novedades@callcenter.com",
            "destinoErrores": "tmo-errores@callcenter.com",
            "asuntoReporteContiene": "[TMO] Reporte consolidado"
        }
    }


def buscar_columna(claves, nombre_config, alternativas):
    indice = {normalizar_clave(k): k for k in claves}
    candidatos = [nombre_config] + list(alternativas)
    for cand in candidatos:
        if cand:
            norm = normalizar_clave(cand)
            if norm in indice:
                return indice[norm]
    return None


def resolver_columnas(claves, config_columnas):
    col = config_columnas or {}
    
    def match_col(patrones):
        for k in claves:
            norm = normalizar_clave(k)
            for p in patrones:
                if re.search(p, norm):
                    return k
        return None

    agente = buscar_columna(claves, col.get('agente', 'Agente'), ['agente', 'nombre agente', 'asesor', 'nombre asesor']) or match_col([r'\bagente\b', r'\basesor\b'])
    tiempo = buscar_columna(claves, col.get('tiempo', 'Tiempo de gestión'), ['tiempo de gestion', 'tiempo', 'duracion', 'duracion segundos', 'tmo']) or match_col([r'tiempo.*gesti', r'duraci', r'\btmo\b', r'\btiempo\b'])
    id_gestion = buscar_columna(claves, col.get('idGestion', 'ID Gestion'), ['id gestion', 'id', 'id_gestion', 'identificador']) or match_col([r'\bid\b', r'id.*gesti'])
    fecha = buscar_columna(claves, col.get('fecha', 'Fecha'), ['fecha', 'fecha gestion', 'fecha y hora']) or match_col([r'\bfecha\b'])
    canal = buscar_columna(claves, col.get('canal', 'Canal'), ['canal', 'medio']) or match_col([r'\bcanal\b', r'\bmedio\b'])
    campania = buscar_columna(claves, col.get('campania', 'Campaña'), ['campana', 'campaña']) or match_col([r'campan', r'campa'])

    return {
        "agente": agente,
        "tiempo": tiempo,
        "idGestion": id_gestion,
        "fecha": fecha,
        "canal": canal,
        "campania": campania
    }


def calcular_tmo(filas, config, fecha_procesamiento=None):
    if not fecha_procesamiento:
        fecha_procesamiento = fecha_actual_str()

    lista = filas if isinstance(filas, list) else []
    if not lista:
        return {
            "ok": False,
            "codigo": "SIN_REGISTROS",
            "mensaje": "El archivo no contiene registros.",
            "columnasEncontradas": []
        }

    claves = list(lista[0].keys()) if lista else []
    col_cfg = config.get("columnas", {}) if isinstance(config, dict) else {}
    columnas = resolver_columnas(claves, col_cfg)

    if not columnas["agente"] or not columnas["tiempo"]:
        return {
            "ok": False,
            "codigo": "COLUMNAS_FALTANTES",
            "mensaje": "Faltan columnas obligatorias. Se requiere la columna de Agente y Tiempo de gestión.",
            "columnasEncontradas": claves,
            "columnasRequeridas": ["Agente", "Tiempo de gestión"]
        }

    vistos_id = set()
    vistos_combo = set()
    agentes_map = {}
    rechazados = []
    registros_sin_agente = 0
    motivos = {}

    def rechazar(fila_dict, idx, motivo, nombre_agente):
        nonlocal registros_sin_agente
        motivos[motivo] = motivos.get(motivo, 0) + 1
        if not nombre_agente:
            registros_sin_agente += 1
        else:
            if nombre_agente not in agentes_map:
                agentes_map[nombre_agente] = {
                    "agente": nombre_agente,
                    "gestiones": 0,
                    "suma": 0.0,
                    "rechazados": 0
                }
            agentes_map[nombre_agente]["rechazados"] += 1

        reg = {
            'Fila origen': idx + 2,
            'ID Gestion': texto_plano(fila_dict.get(columnas["idGestion"])),
            'Agente': nombre_agente,
            'Tiempo de gestión': fila_dict.get(columnas["tiempo"], ""),
            'Fecha': texto_plano(fila_dict.get(columnas["fecha"])),
            'Canal': texto_plano(fila_dict.get(columnas["canal"])),
            'Campaña': texto_plano(fila_dict.get(columnas["campania"])),
            'Motivo rechazo': motivo,
            'Fecha de procesamiento': fecha_procesamiento
        }
        rechazados.append(reg)

    for idx, fila in enumerate(lista):
        id_gest = texto_plano(fila.get(columnas["idGestion"]))
        agente = texto_plano(fila.get(columnas["agente"]))

        # Duplicado por ID único
        if id_gest:
            clave_id = f"id:{id_gest}"
            if clave_id in vistos_id:
                rechazar(fila, idx, 'Registro duplicado (ID Gestion ya procesado)', agente)
                continue
            vistos_id.add(clave_id)

        # Validación agente
        if not agente:
            rechazar(fila, idx, 'Agente no identificado', '')
            continue

        # Validación tiempo
        valido, motivo_tiempo, tiempo_num = parsear_tiempo(fila.get(columnas["tiempo"]))
        if not valido:
            rechazar(fila, idx, motivo_tiempo, agente)
            continue

        # Validación combo duplicado
        fecha = texto_plano(fila.get(columnas["fecha"]))
        canal = texto_plano(fila.get(columnas["canal"]))
        if fecha and canal:
            combo = f"combo:{agente}|{fecha}|{canal}|{tiempo_num}"
            if combo in vistos_combo:
                rechazar(fila, idx, 'Registro duplicado (mismo agente, fecha, canal y tiempo)', agente)
                continue
            vistos_combo.add(combo)

        if agente not in agentes_map:
            agentes_map[agente] = {
                "agente": agente,
                "gestiones": 0,
                "suma": 0.0,
                "rechazados": 0
            }

        agentes_map[agente]["gestiones"] += 1
        agentes_map[agente]["suma"] += tiempo_num

    # Generar consolidado ordenado alfabéticamente
    agentes_ordenados = sorted(agentes_map.values(), key=lambda a: normalizar_clave(a["agente"]))
    consolidado = []
    for g in agentes_ordenados:
        tiene_datos = g["gestiones"] > 0
        tmo_prom = redondear(g["suma"] / g["gestiones"], 2) if tiene_datos else ""
        suma_red = redondear(g["suma"], 2) if tiene_datos else ""
        consolidado.append({
            'Agente': g["agente"],
            'Gestiones válidas': g["gestiones"],
            'Tiempo acumulado': suma_red,
            'TMO promedio': tmo_prom,
            'Registros rechazados': g["rechazados"],
            'Fecha de procesamiento': fecha_procesamiento,
            'Observación': 'Calculado' if tiene_datos else 'Sin datos suficientes'
        })

    registros_validos = sum(int(c.get('Gestiones válidas', 0) or 0) for c in consolidado)

    return {
        "ok": True,
        "columnas": columnas,
        "consolidado": consolidado,
        "rechazados": rechazados,
        "resumen": {
            "registrosRecibidos": len(lista),
            "registrosValidos": registros_validos,
            "registrosRechazados": len(rechazados),
            "registrosSinAgente": registros_sin_agente,
            "agentesProcesados": len(consolidado),
            "agentesConDatos": sum(1 for c in consolidado if c.get('Observación') == 'Calculado'),
            "agentesSinDatos": sum(1 for c in consolidado if c.get('Observación') != 'Calculado'),
            "motivos": motivos,
            "fechaProcesamiento": fecha_procesamiento
        }
    }


def clasificar_reporte(filas_consolidado, config, fecha_validacion=None):
    if not fecha_validacion:
        fecha_validacion = fecha_actual_str()

    lista = filas_consolidado if isinstance(filas_consolidado, list) else []
    if not lista:
        return {
            "ok": False,
            "codigo": "SIN_REGISTROS",
            "mensaje": "El reporte consolidado no contiene agentes.",
            "resultados": [],
            "resumen": {}
        }

    limite = float(config.get("tmoLimite", 20))
    resultados = []

    for fila in lista:
        agente = texto_plano(fila.get('Agente'))
        gestiones = fila.get('Gestiones válidas')
        try:
            gestiones = int(gestiones) if gestiones not in (None, "") else None
        except (ValueError, TypeError):
            gestiones = None

        tmo_val = fila.get('TMO promedio')
        try:
            tmo_val = float(str(tmo_val).replace(',', '.')) if tmo_val not in (None, "") else None
        except (ValueError, TypeError):
            tmo_val = None

        obs = texto_plano(fila.get('Observación'))
        rech = fila.get('Registros rechazados', 0)

        base = {
            'Agente': agente,
            'Gestiones válidas': gestiones if gestiones is not None else '',
            'TMO promedio': '',
            'TMO límite': limite,
            'Diferencia frente al límite': '',
            'Clasificación': 'ERROR DE DATOS',
            'Motivo': '',
            'Fecha de validación': fecha_validacion,
            'Registros rechazados origen': rech
        }

        if not agente:
            base['Motivo'] = 'Agente no identificado'
            resultados.append(base)
            continue

        if normalizar_clave(obs) == 'sin datos suficientes' or gestiones is None or gestiones <= 0:
            base['Motivo'] = 'Sin datos suficientes para calcular el promedio'
            resultados.append(base)
            continue

        if tmo_val is None:
            base['Motivo'] = 'TMO promedio vacío o no numérico'
            resultados.append(base)
            continue

        if tmo_val < 0:
            base['Motivo'] = 'TMO promedio negativo'
            resultados.append(base)
            continue

        tmo_red = redondear(tmo_val, 2)
        dif = redondear(tmo_red - limite, 2)
        base['TMO promedio'] = tmo_red
        base['Diferencia frente al límite'] = dif

        if tmo_red <= limite:
            base['Clasificación'] = 'APROBADO'
            base['Motivo'] = 'TMO promedio dentro del límite'
        else:
            base['Clasificación'] = 'REQUIERE REVISIÓN'
            base['Motivo'] = f"Supera el límite por {dif} segundos"

        resultados.append(base)

    aprobados = [r for r in resultados if r['Clasificación'] == 'APROBADO']
    revision = [r for r in resultados if r['Clasificación'] == 'REQUIERE REVISIÓN']
    errores = [r for r in resultados if r['Clasificación'] == 'ERROR DE DATOS']
    evaluables = len(aprobados) + len(revision)

    pct_aprobados = redondear((len(aprobados) / evaluables) * 100, 2) if evaluables > 0 else 0.0
    pct_revision = redondear((len(revision) / evaluables) * 100, 2) if evaluables > 0 else 0.0

    resumen = {
        "totalAgentes": len(resultados),
        "aprobados": len(aprobados),
        "requierenRevision": len(revision),
        "erroresDatos": len(errores),
        "evaluables": evaluables,
        "porcentajeAprobados": pct_aprobados,
        "porcentajeRevision": pct_revision,
        "tmoLimite": limite,
        "fechaValidacion": fecha_validacion
    }

    return {
        "ok": True,
        "resultados": resultados,
        "resumen": resumen,
        "aprobados": aprobados,
        "revision": revision,
        "errores": errores
    }


def filas_resumen(resumen):
    return [
        {"Indicador": "Total de agentes evaluados", "Valor": resumen.get("totalAgentes", 0)},
        {"Indicador": "Agentes aprobados", "Valor": resumen.get("aprobados", 0)},
        {"Indicador": "Agentes que requieren revisión", "Valor": resumen.get("requierenRevision", 0)},
        {"Indicador": "Registros con errores de datos", "Valor": resumen.get("erroresDatos", 0)},
        {"Indicador": "Agentes evaluables", "Valor": resumen.get("evaluables", 0)},
        {"Indicador": "Porcentaje de agentes aprobados", "Valor": f"{resumen.get('porcentajeAprobados', 0)}%"},
        {"Indicador": "Porcentaje que requiere revisión", "Valor": f"{resumen.get('porcentajeRevision', 0)}%"},
        {"Indicador": "TMO límite aplicado", "Valor": f"{resumen.get('tmoLimite', 20)} segundos"},
        {"Indicador": "Fecha de validación", "Valor": resumen.get("fechaValidacion", "")}
    ]


# ---------------------------------------------------------------------------
# LECTURA Y ESCRITURA DE EXCEL (XLSX) Y CSV EN PYTHON PURO
# ---------------------------------------------------------------------------

def leer_archivo_tabular(ruta_o_bytes, extension=".xlsx"):
    """Lee un archivo Excel (.xlsx) o CSV y retorna una lista de diccionarios"""
    ext = extension.lower()
    if ext == ".csv":
        return leer_csv(ruta_o_bytes)
    return leer_xlsx(ruta_o_bytes)


def leer_csv(ruta_o_bytes):
    if isinstance(ruta_o_bytes, (bytes, bytearray)):
        texto = ruta_o_bytes.decode('utf-8', errors='replace')
        f = io.StringIO(texto)
    else:
        f = open(ruta_o_bytes, 'r', encoding='utf-8', errors='replace')

    try:
        sample = f.read(2048)
        f.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=',;\t')
            delimiter = dialect.delimiter
        except Exception:
            delimiter = ';' if ';' in sample else ','
        reader = csv.DictReader(f, delimiter=delimiter)
        return list(reader)
    finally:
        f.close()


def leer_xlsx(ruta_o_bytes):
    """Lee hojas de un archivo .xlsx usando standard library zipfile y xml.etree"""
    bio = io.BytesIO(ruta_o_bytes) if isinstance(ruta_o_bytes, (bytes, bytearray)) else ruta_o_bytes
    ns = {'main': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    
    with zipfile.ZipFile(bio, 'r') as z:
        shared_strings = []
        if 'xl/sharedStrings.xml' in z.namelist():
            tree = ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in tree.findall('main:si', ns):
                t = si.find('main:t', ns)
                if t is not None:
                    shared_strings.append(t.text or '')
                else:
                    shared_strings.append(''.join(t_el.text or '' for t_el in si.findall('.//main:t', ns)))
        
        # Encontrar la primera hoja
        sheet_filename = 'xl/worksheets/sheet1.xml'
        for name in z.namelist():
            if name.startswith('xl/worksheets/sheet') and name.endswith('.xml'):
                sheet_filename = name
                break
        
        sheet_tree = ET.fromstring(z.read(sheet_filename))
        rows = []
        for row in sheet_tree.findall('.//main:row', ns):
            row_data = {}
            for c in row.findall('main:c', ns):
                cell_ref = c.attrib.get('r', '')
                col = re.sub(r'[0-9]', '', cell_ref)
                cell_type = c.attrib.get('t', '')
                v = c.find('main:v', ns)
                val = v.text if v is not None else ''
                if cell_type == 's' and val.isdigit():
                    idx = int(val)
                    if idx < len(shared_strings):
                        val = shared_strings[idx]
                elif cell_type == 'inlineStr':
                    is_t = c.find('.//main:is/main:t', ns)
                    val = is_t.text if is_t is not None else val
                row_data[col] = val
            if row_data:
                rows.append(row_data)

        if not rows:
            return []

        # Determinar orden de columnas
        headers_row = rows[0]
        # Ordenar columnas alfabéticamente por etiqueta (A, B, C...)
        def col_key(c):
            # convertir 'A' -> 1, 'AA' -> 27
            num = 0
            for char in c:
                num = num * 26 + (ord(char) - ord('A') + 1)
            return num

        sorted_cols = sorted(headers_row.keys(), key=col_key)
        headers = [headers_row[c] for c in sorted_cols if headers_row[c]]

        result = []
        for r in rows[1:]:
            item = {}
            for c in sorted_cols:
                h = headers_row.get(c)
                if h:
                    item[h] = r.get(c, '')
            result.append(item)
        return result


def generar_xlsx_bytes(hojas_dict) -> bytes:
    """
    Genera un archivo .xlsx estándar en memoria usando zipfile y XML.
    hojas_dict = {'NombreHoja': [list de diccionarios]}
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        # [Content_Types].xml
        content_types = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
            '<Default Extension="xml" ContentType="application/xml"/>',
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        ]
        
        sheet_items = list(hojas_dict.items())
        for idx, _ in enumerate(sheet_items, 1):
            content_types.append(f'<Override PartName="/xl/worksheets/sheet{idx}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
        content_types.append('</Types>')
        z.writestr('[Content_Types].xml', "\n".join(content_types))

        # _rels/.rels
        rels = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>',
            '</Relationships>'
        ]
        z.writestr('_rels/.rels', "\n".join(rels))

        # xl/_rels/workbook.xml.rels
        wb_rels = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        ]
        for idx, _ in enumerate(sheet_items, 1):
            wb_rels.append(f'<Relationship Id="rId{idx}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{idx}.xml"/>')
        wb_rels.append('</Relationships>')
        z.writestr('xl/_rels/workbook.xml.rels', "\n".join(wb_rels))

        # xl/workbook.xml
        wb_xml = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">',
            '<sheets>'
        ]
        for idx, (nombre_hoja, _) in enumerate(sheet_items, 1):
            nombre_limpio = str(nombre_hoja)[:31].replace(':', '').replace('/', '').replace('\\', '').replace('?', '').replace('*', '').replace('[', '').replace(']', '')
            wb_xml.append(f'<sheet name="{nombre_limpio}" sheetId="{idx}" r:id="rId{idx}"/>')
        wb_xml.append('</sheets></workbook>')
        z.writestr('xl/workbook.xml', "\n".join(wb_xml))

        # Escribir cada hoja
        def idx_to_col(n):
            result = ""
            while n > 0:
                n, rem = divmod(n - 1, 26)
                result = chr(65 + rem) + result
            return result

        for idx, (_, filas) in enumerate(sheet_items, 1):
            headers = []
            if filas and isinstance(filas, list):
                headers = list(filas[0].keys())

            sheet_lines = [
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
                '<sheetData>'
            ]

            row_num = 1
            if headers:
                # Fila de encabezados
                sheet_lines.append(f'<row r="{row_num}">')
                for col_idx, h in enumerate(headers, 1):
                    col_letter = idx_to_col(col_idx)
                    val_str = str(h).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                    sheet_lines.append(f'<c r="{col_letter}{row_num}" t="inlineStr"><is><t>{val_str}</t></is></c>')
                sheet_lines.append('</row>')
                row_num += 1

                # Filas de datos
                for f in filas:
                    sheet_lines.append(f'<row r="{row_num}">')
                    for col_idx, h in enumerate(headers, 1):
                        col_letter = idx_to_col(col_idx)
                        val = f.get(h, '')
                        if val is None:
                            val = ''
                        
                        if isinstance(val, (int, float)) and not math.isnan(val) and not math.isinf(val):
                            sheet_lines.append(f'<c r="{col_letter}{row_num}"><v>{val}</v></c>')
                        else:
                            val_str = str(val).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                            sheet_lines.append(f'<c r="{col_letter}{row_num}" t="inlineStr"><is><t>{val_str}</t></is></c>')
                    sheet_lines.append('</row>')
                    row_num += 1

            sheet_lines.append('</sheetData></worksheet>')
            z.writestr(f'xl/worksheets/sheet{idx}.xml', "\n".join(sheet_lines))

    return buf.getvalue()


# ---------------------------------------------------------------------------
# GENERADOR DE CORREO HTML
# ---------------------------------------------------------------------------

def generar_html_correo_trabajador(trabajador, tipo_plantilla='desempeno', nota_personalizada='', fecha_emision=None):
    if not fecha_emision:
        fecha_emision = fecha_actual_str()

    clasificacion = trabajador.get('clasificacion', 'APROBADO')
    es_aprobado = clasificacion == 'APROBADO'
    es_revision = clasificacion == 'REQUIERE REVISIÓN'

    color_tema = '#10b981' if es_aprobado else ('#ef4444' if es_revision else '#6b7280')
    icono_estado = '✅' if es_aprobado else ('⚠️' if es_revision else 'ℹ️')
    titulo_estado = 'OBJETIVO CUMPLIDO (APROBADO)' if es_aprobado else ('REQUIERE ATENCIÓN OPERACIONAL' if es_revision else 'SIN DATOS SUFICIENTES')

    tmo_prom = trabajador.get('tmoPromedio')
    tmo_lim = trabajador.get('tmoLimite', 20)
    dif = trabajador.get('diferencia')

    if es_aprobado:
        mensaje_mot = f"""
        <div style="background-color: #ecfdf5; border-left: 4px solid #10b981; padding: 14px 18px; margin: 18px 0; border-radius: 6px;">
          <strong style="color: #065f46; font-size: 15px;">¡Excelente desempeño!</strong>
          <p style="margin: 6px 0 0 0; color: #047857; font-size: 14px; line-height: 1.5;">Tu TMO promedio de <strong>{tmo_prom}s</strong> se encuentra dentro del umbral corporativo de <strong>{tmo_lim}s</strong>. Felicitaciones por tu agilidad y efectividad en la gestión.</p>
        </div>
        """
    elif es_revision:
        mensaje_mot = f"""
        <div style="background-color: #fef2f2; border-left: 4px solid #ef4444; padding: 14px 18px; margin: 18px 0; border-radius: 6px;">
          <strong style="color: #991b1b; font-size: 15px;">Oportunidad de Mejora</strong>
          <p style="margin: 6px 0 0 0; color: #b91c1c; font-size: 14px; line-height: 1.5;">Tu TMO promedio de <strong>{tmo_prom}s</strong> supera la meta corporativa de <strong>{tmo_lim}s</strong> por <strong>+{dif}s</strong>. Te invitamos a optimizar tus tiempos de llamada y cierre de gestión.</p>
        </div>
        """
    else:
        mensaje_mot = f"""
        <div style="background-color: #f3f4f6; border-left: 4px solid #9ca3af; padding: 14px 18px; margin: 18px 0; border-radius: 6px;">
          <strong style="color: #374151; font-size: 15px;">Registros Insuficientes</strong>
          <p style="margin: 6px 0 0 0; color: #4b5563; font-size: 14px; line-height: 1.5;">No se registraron gestiones válidas en este corte para calcular tu promedio de TMO.</p>
        </div>
        """

    bloque_nota = ""
    if nota_personalizada:
        bloque_nota = f"""
        <div style="background-color: #fffbeb; border: 1px solid #fde68a; padding: 14px 16px; margin: 18px 0; border-radius: 6px;">
          <strong style="color: #92400e; font-size: 13px; text-transform: uppercase;">Nota del Supervisor:</strong>
          <p style="margin: 6px 0 0 0; color: #78350f; font-size: 14px; line-height: 1.5;">{nota_personalizada}</p>
        </div>
        """

    rechazados_row = ""
    if trabajador.get('rechazados', 0) > 0:
        rechazados_row = f"""
        <tr>
          <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; color: #dc2626;">Registros con inconsistencia / descartados</td>
          <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 600; color: #dc2626;">{trabajador['rechazados']}</td>
        </tr>
        """

    dif_str = f"+{dif} seg" if dif and dif > 0 else (f"{dif} seg" if dif is not None else "N/A")
    dif_color = "#dc2626" if dif and dif > 0 else "#16a34a"

    return f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Notificación TMO</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 24px; color: #1e293b;">
  <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0;">
    
    <!-- Encabezado -->
    <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 26px 20px; text-align: center; color: #ffffff;">
      <div style="font-size: 12px; text-transform: uppercase; letter-spacing: 2px; opacity: 0.85; margin-bottom: 6px;">Control de Rendimiento Operacional</div>
      <h1 style="margin: 0; font-size: 22px; font-weight: 700;">Reporte Individual de TMO (Python Edition)</h1>
      <div style="font-size: 13px; opacity: 0.8; margin-top: 5px;">Tiempo Medio Operativo | Centro de Contacto</div>
    </div>

    <!-- Cuerpo -->
    <div style="padding: 26px;">
      <p style="font-size: 16px; margin-top: 0;">Estimado(a) <strong>{trabajador.get('agente', 'Asesor')}</strong>,</p>
      <p style="font-size: 14px; color: #475569; line-height: 1.6;">
        A continuación te presentamos el resultado oficial del cálculo de tu <strong>Tiempo Medio Operativo (TMO)</strong> registrado en el sistema:
      </p>

      <!-- Badge de Estado -->
      <div style="text-align: center; margin: 22px 0;">
        <span style="display: inline-block; background-color: {color_tema}; color: #ffffff; padding: 9px 20px; border-radius: 24px; font-weight: 700; font-size: 14px; letter-spacing: 0.5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          {icono_estado} {titulo_estado}
        </span>
      </div>

      {mensaje_mot}
      {bloque_nota}

      <!-- Tabla de Indicadores -->
      <table style="width: 100%; border-collapse: collapse; margin-top: 22px; font-size: 14px;">
        <thead>
          <tr style="background-color: #f1f5f9;">
            <th style="padding: 12px 14px; text-align: left; border-bottom: 2px solid #cbd5e1; color: #475569; font-weight: 600;">Indicador Operativo</th>
            <th style="padding: 12px 14px; text-align: right; border-bottom: 2px solid #cbd5e1; color: #475569; font-weight: 600;">Resultado</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; color: #334155;">Gestiones Válidas Analizadas</td>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 600;">{trabajador.get('gestionesValidas', 0)}</td>
          </tr>
          <tr>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; color: #334155;">Tiempo Total Acumulado</td>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 600;">{trabajador.get('tiempoAcumulado', 'N/A')} seg</td>
          </tr>
          <tr style="background-color: #f8fafc;">
            <td style="padding: 14px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-weight: 700; font-size: 15px;">Tu TMO Promedio Obtenido</td>
            <td style="padding: 14px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 700; font-size: 17px; color: {color_tema};">
              {tmo_prom if tmo_prom is not None else 'Sin datos'} s
            </td>
          </tr>
          <tr>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; color: #334155;">Meta de Operación (TMO Límite)</td>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 600;">{tmo_lim} segundos</td>
          </tr>
          <tr>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; color: #334155;">Variación frente a la Meta</td>
            <td style="padding: 11px 14px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 600; color: {dif_color};">
              {dif_str}
            </td>
          </tr>
          {rechazados_row}
        </tbody>
      </table>

      <!-- Recomendaciones -->
      <div style="margin-top: 24px; padding: 16px; background-color: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0;">
        <h4 style="margin: 0 0 10px 0; font-size: 13px; text-transform: uppercase; color: #475569; letter-spacing: 0.5px;">Recomendaciones para tu gestión:</h4>
        <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #64748b; line-height: 1.6;">
          <li>Realiza la tipificación y notas durante la llamada para agilizar el wrap-up.</li>
          <li>Asegúrate de que cada gestión tenga registrado un ID único y tiempo válido en segundos.</li>
          <li>Si requieres apoyo en gestión del tiempo, acércate a tu supervisor de turno.</li>
        </ul>
      </div>

    </div>

    <!-- Pie -->
    <div style="background-color: #f1f5f9; padding: 18px 24px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0;">
      Correo generado automáticamente por la Plataforma Web de Medición de TMO (Python).<br>
      Fecha de emisión: {fecha_emision} | Coordinación de Operaciones
    </div>

  </div>
</body>
</html>
"""
